package com.example.recipeapp.entities
@Entity(tableName)
class Recipes ()